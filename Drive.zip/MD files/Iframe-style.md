 html, body {
      height:100%;
         background-color: black;
         }