<!--Note - use in <style> tag, in the <head> section.-->

 
body {
  background-color: black;
}

container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  text-align: center;
  height: 100vh;
}

h1 {
  color: white;
  text-align: center;
}
p {
  color: white;
  text-align: center;
}