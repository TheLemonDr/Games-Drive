<!--in css body, footer, and article-->

<!--body-->

min-height: 100vh;
      display: flex;
      flex-direction: column;


<!--footer-->

margin-top: auto;


<!--article-->

 margin: auto 0;